﻿To install the PMU Connection Tester, extract and run PMUConnectionTesterSetup.msi.
The MSI may also be used to upgrade an existing version of PMU Connection Tester.
Any needed configuration will be preserved across installations.

PMU Connection Tester product page:
http://www.gridprotectionalliance.org/products.asp#Connection

PMU Connection Tester on GitHub:
https://github.com/GridProtectionAlliance/PMUConnectionTester

PMU Connection Tester discussions:
http://discussions.gridprotectionalliance.org/c/gpa-products/pmu-connection-tester